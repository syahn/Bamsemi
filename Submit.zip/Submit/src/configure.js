// Initialize Firebase
var config = {
  apiKey: "AIzaSyAJvHLBJ1eqeSGwrv2z2DsMaow1NFaW8lM",
  authDomain: "bamsemi-efb21.firebaseapp.com",
  databaseURL: "https://bamsemi-efb21.firebaseio.com",
  storageBucket: "bamsemi-efb21.appspot.com",
};

firebase.initializeApp(config);


  
