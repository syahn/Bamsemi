# Bamsemi: Find 24 hours cafe in Seoul

This one-page web app is for the designers, developers, students, and all the people who need to find nearby 24-hour cafes.

### Features

* Find nearby 24-cafe by clicking geolocation button
* Filter by brands
* Get a tip of good place around 24-hour cafe with the Foursquare API.


#### Foursquare API & Google map API

For building this app, I used foursquare API and google map API.
